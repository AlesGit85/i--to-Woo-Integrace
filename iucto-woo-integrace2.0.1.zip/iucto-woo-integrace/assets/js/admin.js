/**
 * iÚčto Woo Integrace - Admin JavaScript
 * 
 * @package IUcto_Woo_Integration
 * @since 2.0.0
 */

(function($) {
    'use strict';
    
    /**
     * Inicializace po načtení DOM
     */
    $(document).ready(function() {
        
        // Inicializace settings page
        if ($('.iucto-settings-wrap').length) {
            initSettingsPage();
        }
        
        // Inicializace order detail page
        if ($('.iucto-invoice-meta-box').length) {
            initOrderDetailPage();
        }
    });
    
    /**
     * Inicializace settings stránky
     */
    function initSettingsPage() {
        console.log('iÚčto: Settings page initialized');
        
        // TODO: Ajax test připojení
        // TODO: Live validace formuláře
        // TODO: Auto-save draftu
        
        // Zatím jen basic validace IČO
        $('#iucto_company_ico').on('blur', function() {
            var ico = $(this).val();
            if (ico && !ico.match(/^\d{8}$/)) {
                $(this).css('border-color', '#dc3232');
                if (!$(this).next('.ico-error').length) {
                    $(this).after('<p class="ico-error" style="color: #dc3232;">IČO musí obsahovat přesně 8 číslic</p>');
                }
            } else {
                $(this).css('border-color', '');
                $(this).next('.ico-error').remove();
            }
        });
        
        // Validace sazby DPH
        $('#iucto_vat_rate').on('input', function() {
            var rate = parseInt($(this).val());
            if (rate < 0 || rate > 100) {
                $(this).css('border-color', '#dc3232');
            } else {
                $(this).css('border-color', '');
            }
        });
        
        // Validace splatnosti
        $('#iucto_invoice_maturity').on('input', function() {
            var days = parseInt($(this).val());
            if (days < 1 || days > 365) {
                $(this).css('border-color', '#dc3232');
            } else {
                $(this).css('border-color', '');
            }
        });
    }
    
    /**
     * Inicializace order detail stránky
     */
    function initOrderDetailPage() {
        console.log('iÚčto: Order detail page initialized');
        
        // TODO: Tlačítko pro manuální vytvoření faktury
        // TODO: Tlačítko pro storno faktury
        // TODO: Preview faktury
    }
    
    /**
     * Ajax test připojení k API
     * 
     * TODO: Implementovat
     */
    function testApiConnection() {
        var button = $('.iucto-test-connection');
        
        // Disable tlačítko a přidej loader
        button.prop('disabled', true);
        button.find('.button-text').text('Testuji připojení...');
        button.append('<span class="iucto-loading"></span>');
        
        $.ajax({
            url: iuctoWooAdmin.ajax_url,
            type: 'POST',
            data: {
                action: 'iucto_test_connection',
                nonce: iuctoWooAdmin.nonce
            },
            success: function(response) {
                // Zobrazit výsledek
                console.log('Test result:', response);
                
                // Re-enable tlačítko
                button.prop('disabled', false);
                button.find('.button-text').text('Otestovat připojení');
                button.find('.iucto-loading').remove();
                
                // Zobrazit notice
                if (response.success) {
                    showNotice('Test připojení úspěšný', 'success');
                } else {
                    showNotice('Test připojení selhal: ' + response.data.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.error('Ajax error:', error);
                
                // Re-enable tlačítko
                button.prop('disabled', false);
                button.find('.button-text').text('Otestovat připojení');
                button.find('.iucto-loading').remove();
                
                showNotice('Chyba při testování: ' + error, 'error');
            }
        });
    }
    
    /**
     * Zobrazí admin notice
     * 
     * @param {string} message Zpráva
     * @param {string} type Typ (success, error, warning, info)
     */
    function showNotice(message, type) {
        type = type || 'info';
        
        var notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        
        $('.wrap h1').after(notice);
        
        // Auto dismiss po 5 sekundách
        setTimeout(function() {
            notice.fadeOut(function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    /**
     * Utility funkce pro debounce
     * 
     * @param {function} func Funkce k debounce
     * @param {number} wait Čas v ms
     * @return {function} Debounced funkce
     */
    function debounce(func, wait) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                func.apply(context, args);
            }, wait);
        };
    }
    
})(jQuery);
